package com.atakavuncu.booktime.ui.profile.all_books

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavHostController
import com.atakavuncu.booktime.R
import com.atakavuncu.booktime.ui.components.BTAppBar
import com.atakavuncu.booktime.ui.helper.BookCategory
import com.atakavuncu.booktime.ui.theme.BackgroundWhite

data class Book(
    val id: Int,
    val title: String,
    val imageRes: Int,
    val status: BookStatus
)

enum class BookStatus {
    READING, NOT_STARTED, READ, STOPPED
}

@Composable
fun AllBooksScreen(
    navController: NavHostController
) {
    val books = listOf(
        Book(id = 1, title = "Satranç", imageRes = R.drawable.book4, status = BookStatus.READING),
        Book(id = 2, title = "1984", imageRes = R.drawable.book1, status = BookStatus.READING),
        Book(id = 3, title = "Nutuk", imageRes = R.drawable.book3, status = BookStatus.READING),
        Book(id = 4, title = "Dönüşüm", imageRes = R.drawable.book8, status = BookStatus.NOT_STARTED),
        Book(id = 5, title = "Kürk Mantolu Madonna", imageRes = R.drawable.book6, status = BookStatus.NOT_STARTED),
        Book(id = 6, title = "Beyaz Zambaklar Ülkesinde", imageRes = R.drawable.book11, status = BookStatus.NOT_STARTED),
        Book(id = 7, title = "Körlük", imageRes = R.drawable.book2, status = BookStatus.NOT_STARTED),
        Book(id = 8, title = "On Kişiydiler", imageRes = R.drawable.book9, status = BookStatus.NOT_STARTED),
        Book(id = 9, title = "Ben, Robot", imageRes = R.drawable.book10, status = BookStatus.NOT_STARTED),
        Book(id = 10, title = "Hayvan Çiftliği", imageRes = R.drawable.book5, status = BookStatus.READ),
        Book(id = 11, title = "Cumhuriyet Türk Mucizesi", imageRes = R.drawable.book12, status = BookStatus.READ),
        Book(id = 12, title = "Buçuklu Semtin Hergele Çocukları", imageRes = R.drawable.book7, status = BookStatus.READ),
        Book(id = 13, title = "Sol Ayağım", imageRes = R.drawable.book13, status = BookStatus.READ),
        Book(id = 14, title = "Tarihi Tersten Okumak", imageRes = R.drawable.book14, status = BookStatus.READ),
        Book(id = 15, title = "Martı Jonathan Livingston", imageRes = R.drawable.book15, status = BookStatus.READ),
        Book(id = 15, title = "Martı Jonathan Livingston", imageRes = R.drawable.book15, status = BookStatus.READ),
        Book(id = 16, title = "Cesur Yeni Dünya", imageRes = R.drawable.book16, status = BookStatus.STOPPED)
    )

    Scaffold(
        topBar = {
            BTAppBar(title = stringResource(id = R.string.all_books), navController = navController)
        },
        containerColor = BackgroundWhite
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(top = paddingValues.calculateTopPadding())
                .verticalScroll(rememberScrollState())
        ) {
            BookCategory(stringResource(id = R.string.reading), books.filter { it.status == BookStatus.READING })
            BookCategory(stringResource(id = R.string.not_started), books.filter { it.status == BookStatus.NOT_STARTED })
            BookCategory(stringResource(id = R.string.read), books.filter { it.status == BookStatus.READ })
            BookCategory(stringResource(id = R.string.stopped), books.filter { it.status == BookStatus.STOPPED })
        }
    }
}
