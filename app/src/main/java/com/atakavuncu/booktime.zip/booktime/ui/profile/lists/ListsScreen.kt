package com.atakavuncu.booktime.ui.profile.lists

import androidx.compose.runtime.Composable

@Composable
fun ListsScreen() {

}