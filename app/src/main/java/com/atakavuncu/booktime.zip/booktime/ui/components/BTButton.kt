package com.atakavuncu.booktime.ui.components

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BTButton(
    text: String,
    width: Int? = null,
    height: Int? = null,
    backgroundColor: Color,
    textColor: Color,
    textSize: Int = 12,
    textWeight: FontWeight = FontWeight.Normal,
    paddingValue: PaddingValues? = null,
    shape: Shape? = null,
    onClick: () -> Unit
) {
    val paddingValues: PaddingValues = paddingValue ?: ButtonDefaults.ContentPadding
    val buttonShape: Shape = shape ?: ButtonDefaults.shape

    val buttonModifier = Modifier
        .then(if (height != null) Modifier.height(height.dp) else Modifier)
        .then(if (width != null) Modifier.width(width.dp) else Modifier)

    Button(
        onClick = onClick,
        modifier = buttonModifier,
        shape = buttonShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor,
            contentColor = textColor
        ),
        contentPadding = paddingValues
    ) {
        Text(text = text, fontSize = textSize.sp, fontWeight = textWeight)
    }
}