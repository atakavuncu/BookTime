package com.atakavuncu.booktime

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.atakavuncu.booktime.ui.auth.LoginScreen
import com.atakavuncu.booktime.ui.auth.UserViewModel
import com.atakavuncu.booktime.ui.components.BottomNavigationBar
import com.atakavuncu.booktime.ui.navigation.NavGraph
import com.atakavuncu.booktime.ui.navigation.Route
import com.atakavuncu.booktime.utils.SessionManager

@Composable
fun BookTimeApp(
    sessionManager: SessionManager,
    navController: NavHostController,
    userViewModel: UserViewModel = hiltViewModel()
) {
    var isLoggedIn by remember { mutableStateOf(sessionManager.isLoggedIn()) }
    val loginResult by userViewModel.loginResult.collectAsState()
    val registerResult by userViewModel.registerResult.collectAsState()

    if (isLoggedIn) {
        BottomNavigationBar(navController, sessionManager)
    } else {
        NavGraph(
            sessionManager = sessionManager,
            navController = navController,
            startRoute = Route.LOGIN
        )
    }

    LaunchedEffect(loginResult) {
        loginResult?.let { user ->
            sessionManager.saveUserSession(user)
            isLoggedIn = true
        }
    }

    LaunchedEffect(registerResult) {
        if (registerResult) {
            loginResult?.let { user ->
                sessionManager.saveUserSession(user)
                isLoggedIn = true
            }
        }
    }

    LaunchedEffect(sessionManager.isLoggedIn()) {
        isLoggedIn = sessionManager.isLoggedIn()
    }
}
