package com.atakavuncu.booktime.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.atakavuncu.booktime.data.model.user.User
import com.atakavuncu.booktime.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {
    private val _loginResult = MutableStateFlow<User?>(null)
    val loginResult: StateFlow<User?> = _loginResult

    private val _registerResult = MutableStateFlow(false)
    val registerResult: StateFlow<Boolean> = _registerResult

    fun loginUser(username: String, password: String) {
        viewModelScope.launch {
            val user = userRepository.loginUser(username, password)
            _loginResult.value = user
        }
    }

    fun registerUser(user: User) {
        viewModelScope.launch {
            userRepository.registerUser(user)
            _registerResult.value = true
        }
    }
}