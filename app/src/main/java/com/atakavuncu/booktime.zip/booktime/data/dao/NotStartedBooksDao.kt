package com.atakavuncu.booktime.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.atakavuncu.booktime.data.model.user.NotStartedBooks

@Dao
interface NotStartedBooksDao {
    @Insert
    suspend fun insertNotStartedBooks(notStartedBooks: NotStartedBooks)

    @Delete
    suspend fun deleteNotStartedBooks(notStartedBooks: NotStartedBooks)

    @Query("SELECT * FROM not_started_books WHERE userId = :userId")
    suspend fun getNotStartedBooksByUserId(userId: Int): List<NotStartedBooks>?
}