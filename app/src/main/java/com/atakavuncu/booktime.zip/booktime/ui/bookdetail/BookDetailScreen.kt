package com.atakavuncu.booktime.ui.bookdetail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.atakavuncu.booktime.R
import com.atakavuncu.booktime.ui.components.BTIconText
import com.atakavuncu.booktime.ui.components.BTRadioButtons
import com.atakavuncu.booktime.ui.components.BTSpace
import com.atakavuncu.booktime.ui.components.PageNumberPicker
import com.atakavuncu.booktime.ui.theme.BackgroundWhite
import com.atakavuncu.booktime.ui.theme.Black
import com.atakavuncu.booktime.ui.theme.BookTimeTheme
import com.atakavuncu.booktime.ui.theme.White
import kotlinx.coroutines.delay

@Composable
fun BookDetailScreen(
    navController: NavHostController,
    bookDetailViewModel: BookDetailViewModel = hiltViewModel(),
    bookId: String
) {
    val bookDetail by bookDetailViewModel.book.collectAsState()
    var showLoading by remember { mutableStateOf(true) }
    var showNoResults by remember { mutableStateOf(false) }
    val currentBookDetail by rememberUpdatedState(bookDetail)

    LaunchedEffect(bookId) {
        bookDetailViewModel.getBookDetails(bookId)
    }

    LaunchedEffect(Unit) {
        delay(10000)
        showLoading = false
        if (currentBookDetail?.description?.description == "") {
            showNoResults = true
        }
    }

    LaunchedEffect(bookDetail?.description?.description) {
        if (bookDetail?.description?.description != "") {
            showLoading = false
            showNoResults = false
        }
    }

    BookTimeTheme {
        var selectedPageNumber by remember { mutableIntStateOf(0) }
        Scaffold(
            content = { paddingValues ->
                LazyColumn() {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp)
                        ) {
                            AsyncImage(
                                model = bookDetail?.book?.coverUrl,
                                contentDescription = bookDetail?.book?.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(210.dp)
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Black
                                            ),
                                            startY = 100f
                                        )
                                    )
                            )
                            IconButton(
                                onClick = { navController.popBackStack() }
                            ) {
                                Icon(
                                    imageVector = ImageVector.vectorResource(id = R.drawable.baseline_arrow_back),
                                    contentDescription = stringResource(id = R.string.back),
                                    modifier = Modifier.size(16.dp),
                                    tint = White,
                                )
                            }
                            bookDetail?.book?.title?.let {
                                Text(
                                    text = it,
                                    color = White,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 24.sp,
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(
                                            start = 16.dp,
                                            bottom = paddingValues.calculateTopPadding()
                                        )
                                )
                            }
                            bookDetail?.book?.authorName?.let {
                                Text(
                                    text = it.joinToString(", "),
                                    color = White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 16.sp,
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(start = 16.dp, bottom = 8.dp)
                                )
                            }
                        }
                        Column(
                            Modifier.padding(
                                top = 24.dp,
                                start = 16.dp,
                                end = 16.dp
                            )
                        ) {
                            Text(
                                text = stringResource(id = R.string.information),
                                color = Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Column(
                                modifier = Modifier
                                    .padding(vertical = 12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .padding(bottom = 12.dp)
                                ) {
                                    BTIconText(
                                        iconVector = ImageVector.vectorResource(id = R.drawable.page_count_24),
                                        text = bookDetail?.book?.pageCount.toString() + " " + stringResource(
                                            id = R.string.pages
                                        )
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .padding(bottom = 12.dp)
                                ) {
                                    BTIconText(
                                        iconVector = ImageVector.vectorResource(id = R.drawable.calendar_24),
                                        text = bookDetail?.book?.year.toString()
                                    )
                                }

                            }
                            Text(
                                text = stringResource(id = R.string.reading_status),
                                color = Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                modifier = Modifier.padding(end = 12.dp)
                            )
                            var selectedOption by remember { mutableStateOf("Okuyorum") }
                            val options = listOf("Okudum", "Okuyorum", "Durduruldu", "Okumadım")
                            BTRadioButtons(
                                options = options,
                                selectedOption = selectedOption,
                                onOptionSelected = { selectedOption = it }
                            )
                            BTSpace(spaceHeight = 5)
                            bookDetail?.book?.pageCount?.let { pageCount ->
                                PageNumberPicker(range = 0..pageCount) {
                                    selectedPageNumber = it
                                }
                            }
                            Text(
                                text = stringResource(id = R.string.description),
                                color = Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            when {
                                showLoading -> {
                                    CircularProgressIndicator()
                                }

                                showNoResults -> {
                                    Text(
                                        text = stringResource(id = R.string.description_not_found),
                                        color = Black,
                                        fontSize = 12.sp
                                    )
                                }

                                else -> {
                                    bookDetail?.description?.description?.let {
                                        Text(
                                            text = it,
                                            color = Black,
                                            fontSize = 12.sp,
                                            lineHeight = 16.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            containerColor = BackgroundWhite
        )
    }
}
