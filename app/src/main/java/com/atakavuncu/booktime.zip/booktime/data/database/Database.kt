package com.atakavuncu.booktime.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.atakavuncu.booktime.data.dao.FavoritesDao
import com.atakavuncu.booktime.data.dao.ListsDao
import com.atakavuncu.booktime.data.dao.NotStartedBooksDao
import com.atakavuncu.booktime.data.dao.ReadBooksDao
import com.atakavuncu.booktime.data.dao.ReadingBooksDao
import com.atakavuncu.booktime.data.dao.StoppedBooksDao
import com.atakavuncu.booktime.data.dao.UserDao
import com.atakavuncu.booktime.data.model.user.Favorites
import com.atakavuncu.booktime.data.model.user.Lists
import com.atakavuncu.booktime.data.model.user.NotStartedBooks
import com.atakavuncu.booktime.data.model.user.ReadBooks
import com.atakavuncu.booktime.data.model.user.ReadingBooks
import com.atakavuncu.booktime.data.model.user.StoppedBooks
import com.atakavuncu.booktime.data.model.user.User

@Database(
    entities = [
        User::class,
        ReadBooks::class,
        ReadingBooks::class,
        StoppedBooks::class,
        NotStartedBooks::class,
        Favorites::class,
        Lists::class
    ],
    version = 1
)
abstract class Database : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun readBooksDao(): ReadBooksDao
    abstract fun readingBooksDao(): ReadingBooksDao
    abstract fun stoppedBooksDao(): StoppedBooksDao
    abstract fun notStartedBooksDao(): NotStartedBooksDao
    abstract fun favoritesDao(): FavoritesDao
    abstract fun listsDao(): ListsDao
}