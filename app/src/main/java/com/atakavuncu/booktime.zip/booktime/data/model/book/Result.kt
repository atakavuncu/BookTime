package com.atakavuncu.booktime.data.model.book

data class Result(
    val docs: Docs
)
