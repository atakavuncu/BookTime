package com.atakavuncu.booktime.data.model.book

data class Description(
    val description: String?
)
