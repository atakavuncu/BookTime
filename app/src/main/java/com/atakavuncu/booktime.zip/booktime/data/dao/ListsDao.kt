package com.atakavuncu.booktime.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.atakavuncu.booktime.data.model.user.Lists

@Dao
interface ListsDao {
    @Insert
    suspend fun insertList(lists: Lists)

    @Update
    suspend fun updateList(lists: Lists)

    @Delete
    suspend fun deleteList(lists: Lists)

    @Query("SELECT * FROM lists WHERE userId = :userId")
    suspend fun getListByUserId(userId: Int): Lists?
}