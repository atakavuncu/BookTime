package com.atakavuncu.booktime.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.atakavuncu.booktime.data.model.user.ReadingBooks

@Dao
interface ReadingBooksDao {
    @Insert
    suspend fun insertReadingBooks(readingBooks: ReadingBooks)

    @Delete
    suspend fun deleteReadingBooks(readingBooks: ReadingBooks)

    @Query("SELECT * FROM reading_books WHERE userId = :userId")
    suspend fun getReadingBooksByUserId(userId: Int): List<ReadingBooks>?
}