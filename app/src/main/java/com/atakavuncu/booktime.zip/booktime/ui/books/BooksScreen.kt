package com.atakavuncu.booktime.ui.books

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.atakavuncu.booktime.ui.theme.BookTimeTheme
import androidx.compose.ui.Alignment
import com.atakavuncu.booktime.ui.components.BookCard
import com.atakavuncu.booktime.ui.theme.BackgroundWhite
import com.atakavuncu.booktime.ui.theme.Black
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BooksScreen(navController: NavHostController, viewModel: BooksViewModel = hiltViewModel()) {
    val books by viewModel.books.collectAsState()
    var showLoading by remember { mutableStateOf(true) }
    var showNoResults by remember { mutableStateOf(false) }
    val currentBooks by rememberUpdatedState(books)

    LaunchedEffect(Unit) {
        delay(5000)
        showLoading = false
        if (currentBooks.isEmpty()) {
            showNoResults = true
        }
    }

    LaunchedEffect(books) {
        if (books.isNotEmpty()) {
            showLoading = false
            showNoResults = false
        }
    }

    BookTimeTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("Books") })
            },
            content = { paddingValues ->
                LazyColumn(contentPadding = paddingValues) {
                    when {
                        showLoading -> {
                            item {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator()
                                }
                            }
                        }
                        showNoResults -> {
                            item {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(text = "Sonuç Bulunamadı", color = Black)
                                }
                            }
                        }
                        else -> {
                            items(books) { book ->
                                BookCard(book, navController)
                            }
                        }
                    }
                }
            },
            containerColor = BackgroundWhite
        )
    }
}



