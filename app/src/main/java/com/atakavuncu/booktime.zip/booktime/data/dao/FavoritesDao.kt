package com.atakavuncu.booktime.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.atakavuncu.booktime.data.model.user.Favorites

@Dao
interface FavoritesDao {
    @Insert
    suspend fun insertFavoritesBooks(favorites: Favorites)

    @Delete
    suspend fun deleteFavoritesBooks(favorites: Favorites)

    @Query("SELECT * FROM favorites WHERE userId = :userId")
    suspend fun getFavoritesBooksByUserId(userId: Int): List<Favorites>?
}