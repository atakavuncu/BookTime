package com.atakavuncu.booktime.data.model.book

data class SearchResponse(
    val docs: List<Docs>?
)

