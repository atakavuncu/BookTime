package com.atakavuncu.booktime.ui.helper

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.atakavuncu.booktime.ui.components.BTLabel
import com.atakavuncu.booktime.ui.components.BTSpace
import com.atakavuncu.booktime.ui.components.BookGrid
import com.atakavuncu.booktime.ui.profile.all_books.Book
import com.atakavuncu.booktime.ui.theme.BackgroundWhite
import kotlin.math.ceil

@Composable
fun BookCategory(title: String, books: List<Book>) {
    Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BTLabel(text = title)
        BTSpace(spaceHeight = 8)
        val gridRowCount: Double = ceil(books.size.toDouble() / 3)
        val gridHeight =  gridRowCount * 168
        BookGrid(books = books, gridHeight = gridHeight)
    }
}

@Composable
fun BookItem(book: Book) {
    Column(
        modifier = Modifier
            .padding(4.dp)
            .width(100.dp)
    ) {
        Button(
            onClick = {},
            shape = RoundedCornerShape(5.dp),
            contentPadding = PaddingValues(0.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BackgroundWhite)
        ) {
            Image(
                painter = painterResource(id = book.imageRes),
                contentDescription = book.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .height(160.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(5.dp))
            )
        }
    }
}