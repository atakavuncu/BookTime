package com.atakavuncu.booktime.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import com.atakavuncu.booktime.data.model.user.ReadBooks
import androidx.room.Query

@Dao
interface ReadBooksDao {
    @Insert
    suspend fun insertReadBook(readBook: ReadBooks)

    @Delete
    suspend fun deleteReadBook(readBook: ReadBooks)

    @Query("SELECT * FROM read_books WHERE userId = :userId")
    suspend fun getReadBooksByUserId(userId: Int): List<ReadBooks>?
}