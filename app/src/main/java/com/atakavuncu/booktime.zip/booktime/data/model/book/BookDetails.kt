package com.atakavuncu.booktime.data.model.book

data class BookDetails(
    val book: Book,
    val description: Description?,
)


