package com.atakavuncu.booktime.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.atakavuncu.booktime.data.model.user.StoppedBooks

@Dao
interface StoppedBooksDao {
    @Insert
    suspend fun insertStoppedBooks(stoppedBooks: StoppedBooks)

    @Delete
    suspend fun deleteStoppedBooks(stoppedBooks: StoppedBooks)

    @Query("SELECT * FROM stopped_books WHERE userId = :userId")
    suspend fun getStoppedBooksByUserId(userId: Int): List<StoppedBooks>?
}