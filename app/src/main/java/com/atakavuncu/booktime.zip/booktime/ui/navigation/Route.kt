package com.atakavuncu.booktime.ui.navigation

object Route {
    const val MAIN = "main"
    const val MENU = "menu"
    const val BOOKS = "books"
    const val DISCOVER = "discover"
    const val PROFILE = "profile"
    const val ALL_BOOKS = "all-books"
    const val BOOK_DETAIL = "book-detail/{bookId}"
    const val FAVORITES = "favorites"
    const val LISTS = "lists"
    const val LIST_DETAIL = "list-detail"
    const val LOGIN = "login"
    const val REGISTER = "register"
}