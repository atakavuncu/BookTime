package com.atakavuncu.booktime.data.repository

import com.atakavuncu.booktime.data.dao.UserDao
import com.atakavuncu.booktime.data.model.user.User
import javax.inject.Inject

class UserRepository @Inject constructor(
    private val userDao: UserDao
) {
    suspend fun registerUser(user: User): User {
        userDao.insertUser(user)
        return user
    }

    suspend fun loginUser(username: String, password: String): User? {
        return userDao.getUserByUsernameAndPassword(username, password)
    }

    suspend fun editUser(user: User) {
        userDao.updateUser(user)
    }

    suspend fun deleteUser(user: User) {
        userDao.updateUser(user)
    }
    suspend fun getUserByUserId(userId: Int): User? {
        return userDao.getUserById(userId)
    }
}