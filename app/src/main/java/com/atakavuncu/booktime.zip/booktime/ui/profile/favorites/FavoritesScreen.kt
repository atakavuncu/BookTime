package com.atakavuncu.booktime.ui.profile.favorites

import androidx.compose.runtime.Composable

@Composable
fun FavoritesScreen() {

}