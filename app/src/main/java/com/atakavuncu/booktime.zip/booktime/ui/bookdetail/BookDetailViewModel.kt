package com.atakavuncu.booktime.ui.bookdetail

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.atakavuncu.booktime.data.model.book.BookDetails
import com.atakavuncu.booktime.data.repository.BookRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BookDetailViewModel @Inject constructor(
    private val repository: BookRepository
) : ViewModel() {
    private val _book = MutableStateFlow<BookDetails?>(null)
    val book: StateFlow<BookDetails?> = _book

    fun getBookDetails(bookId: String) {
        viewModelScope.launch {
            val bookDetails = repository.getBookDetails(bookId)
            _book.value = bookDetails
            if (bookDetails == null) {
                Log.e("BookDetailViewModel", "Failed to fetch book details for bookId: $bookId")
            } else {
                Log.d("BookDetailViewModel", "Fetched book details for bookId: $bookId")
            }
        }
    }
}