package com.atakavuncu.booktime.data.repository

import android.util.Log
import com.atakavuncu.booktime.data.api.OpenLibraryApi
import com.atakavuncu.booktime.data.model.book.Book
import com.atakavuncu.booktime.data.model.book.BookDetails
import com.atakavuncu.booktime.data.model.book.Description
import javax.inject.Inject

class BookRepository @Inject constructor(
    private val api: OpenLibraryApi
) {
    suspend fun searchBooks(title: String): List<Book> {
        val response = api.searchBooks(title)
        val docs = response.docs ?: return emptyList()
        return docs.map { result ->
            Book(
                id = result.key.split("/").last(),
                title = result.title,
                authorName = result.authorName,
                coverUrl = result.coverId?.let { "https://covers.openlibrary.org/b/id/$it-M.jpg" },
                pageCount = result.pageCount,
                subject = result.subject,
                year = result.year
            )
        }
    }

    suspend fun getBookDetails(bookId: String): BookDetails? {
        return try {
            val detailResponse = api.getBookDetails(bookId)
            val descriptionResponse = api.getBookDescription(bookId)
            val description = descriptionResponse.description ?: ""
            detailResponse.docs?.get(0)?.let {
                BookDetails(
                    book = Book(
                        id = bookId,
                        title = it.title,
                        authorName = it.authorName,
                        coverUrl = it.coverId?.let { "https://covers.openlibrary.org/b/id/$it-M.jpg" },
                        pageCount = it.pageCount,
                        subject = it.subject,
                        year = it.year
                    ),
                    description = Description(description = description)
                )
            }
        } catch (e: Exception) {
            Log.e("BookRepository", "Error fetching book details", e)
            null
        }
    }
}
