package com.atakavuncu.booktime.utils

import android.content.Context
import android.content.SharedPreferences
import com.atakavuncu.booktime.data.model.user.User

class SessionManager(context: Context) {
    private val preferences: SharedPreferences =
        context.getSharedPreferences("user_session", Context.MODE_PRIVATE)

    companion object {
        const val USER_ID = "user_id"
        const val USERNAME = "username"
        const val IS_LOGGED_IN = "is_logged_in"
    }

    fun saveUserSession(user: User) {
        val editor = preferences.edit()
        editor.putInt(USER_ID, user.userId)
        editor.putString(USERNAME, user.username)
        editor.putBoolean(IS_LOGGED_IN, true)
        editor.apply()
    }

    fun getUserId(): Int {
        return preferences.getInt(USER_ID, -1)
    }

    fun getUsername(): String? {
        return preferences.getString(USERNAME, null)
    }

    fun isLoggedIn(): Boolean {
        return preferences.getBoolean(IS_LOGGED_IN, false)
    }

    fun clearSession() {
        val editor = preferences.edit()
        editor.clear()
        editor.apply()
    }
}