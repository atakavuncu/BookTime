package com.atakavuncu.booktime.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.NavHostController
import com.atakavuncu.booktime.BookTimeApp
import com.atakavuncu.booktime.ui.auth.LoginScreen
import com.atakavuncu.booktime.ui.auth.RegisterScreen
import com.atakavuncu.booktime.ui.bookdetail.BookDetailScreen
import com.atakavuncu.booktime.ui.books.BooksScreen
import com.atakavuncu.booktime.ui.discover.DiscoverScreen
import com.atakavuncu.booktime.ui.menu.MenuScreen
import com.atakavuncu.booktime.ui.profile.ProfileScreen
import com.atakavuncu.booktime.ui.profile.all_books.AllBooksScreen
import com.atakavuncu.booktime.ui.profile.favorites.FavoritesScreen
import com.atakavuncu.booktime.ui.profile.lists.ListsScreen
import com.atakavuncu.booktime.utils.SessionManager

@Composable
fun NavGraph(navController: NavHostController, sessionManager: SessionManager, startRoute: String) {
    NavHost(navController = navController, startDestination = startRoute) {
        composable(Route.MAIN) {
            BookTimeApp(
                sessionManager = sessionManager,
                navController = navController
            )
        }
        composable(Route.MENU) { MenuScreen(sessionManager) }
        composable(Route.BOOKS) { BooksScreen(navController) }
        composable(Route.DISCOVER) { DiscoverScreen() }
        composable(Route.PROFILE) { ProfileScreen(navController) }
        composable(Route.ALL_BOOKS) { AllBooksScreen(navController) }
        composable(Route.FAVORITES) { FavoritesScreen() }
        composable(Route.LISTS) { ListsScreen() }
        composable(Route.BOOK_DETAIL) {
            val bookId = it.arguments?.getString("bookId") ?: ""
            BookDetailScreen(navController = navController, bookId = bookId)
        }
        composable(Route.LOGIN) { LoginScreen(navController) }
        composable(Route.REGISTER) { RegisterScreen(navController) }
    }
}
