package com.atakavuncu.booktime.ui.components

import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.atakavuncu.booktime.ui.helper.BookItem
import com.atakavuncu.booktime.ui.profile.all_books.Book

@Composable
fun BookGrid(
    books: List<Book>,
    gridHeight: Double
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.heightIn(max = gridHeight.dp),
        userScrollEnabled = false
    ) {
        items(books.size) { index ->
            BookItem(book = books[index])
        }
    }
}