package com.atakavuncu.booktime.data.model.user

import androidx.room.Entity
import androidx.room.ForeignKey

@Entity(
    tableName = "lists",
    primaryKeys = ["userId", "listId", "bookId"],
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Lists(
    val userId: Int,
    val listId: Int,
    val listName: String,
    val bookId: String,
)
